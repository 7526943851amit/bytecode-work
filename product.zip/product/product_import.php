<?php
/**
 * Plugin Name: Insert product for product post 
 * Plugin URI: https://www.your-site.com/
 * Description: Import data csv 
 * Version: 0.1
 * Author: Amit sharma
 * Author URI: https://amit-netlify.app/
 **/

 add_action('admin_menu', 'ai_tools_menu');
function ai_tools_menu() {
    add_menu_page('product import', 'product import', 'manage_options', 'my-plugin', 'product_import');
}

function product_import() {
    ?>
    <div class="wrap">
        <h1>Import CSV for product post</h1>
        <form method="post" enctype="multipart/form-data" action="">
             <?php
            if (isset($_POST['import_csv'])) {
                
                if (!empty($_FILES['csv_file']['name'])) {
                    process_csv_data($_FILES['csv_file']['tmp_name']);
                } else {
                    echo '<div class="error"><p>Please select a CSV file.</p></div>';
                }
            }
            ?>
            <input type="file" name="csv_file" id="csv_file" required>
            <input type="submit" name="import_csv" class="button button-primary" value="Import CSV">
        </form>
    </div>
    <?php
}


function process_csv_data($file_path) {
    if (($handle = fopen($file_path, 'r')) !== FALSE) {
        fgetcsv($handle, 1000, ',');

        while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
            $product_title = $data[0];
            $product_description = $data[1];
            $product_image_url = $data[2];
            $product_category = $data[3];
            $regular_price = $data[4];
            $sale_price = $data[5];

            
            
            $post_data = array(
                'post_title'    => $product_title,
                'post_content'  => $product_description,
                'post_status'   => 'publish',
                'post_type'     => 'product',
                'tax_input'     => array(
                
                ),
            );

            $post_id = wp_insert_post($post_data);

           

       
            update_post_meta($post_id, '_regular_price', $regular_price);
            update_post_meta($post_id, '_sale_price', $sale_price);
        }

        fclose($handle);
        echo "Successfully inserted data in product post";
    }
}

