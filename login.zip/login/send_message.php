<?php
  
    require_once 'twilio-php-main/src/Twilio/autoload.php'; 
    use Twilio\Rest\Client;

    $sid    = "AC7bdddae350379b7d39f5c9016792e295";
    $token  = "143ac436b4a6d3f3c0d839734aaa36df";
    $twilio = new Client($sid, $token);

    $message = $twilio->messages
      ->create("+917526943851", // to
        array(
          "from" => "+16065190922",
          "body" => "Your Message"
        )
      );

print($message->sid);