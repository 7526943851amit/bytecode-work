<?php
include 'db.php';
require_once 'twilio-php-main/src/Twilio/autoload.php'; 

session_start();
$sid = "AC7bdddae350379b7d39f5c9016792e295";
$token = "143ac436b4a6d3f3c0d839734aaa36df";
$twilio_number = '+16065190922'; 
if(isset($_POST['submit'])) {
    $phone = $_POST['phone'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM register WHERE phone='$phone' AND Password='$pass'";
    $result = mysqli_query($conn, $sql);

    if($result) {
        if(mysqli_num_rows($result) > 0) {
           
            $otp = generateOTP();

       
            $client = new Client($sid, $token);
            $message = $client->messages->create(
                $phone,
                array(
                    'from' => $twilio_number,
                    'body' => 'Your OTP for login is: ' . $otp
                )
            );

           
            $_SESSION['otp'] = $otp;
            $_SESSION['phone'] = $phone;

            header("Location: otp_verification.php");
            exit();
        } else {
            echo "Invalid phone or password. Please try again.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}

// Function to generate a random OTP
function generateOTP() {
    return mt_rand(1000, 9999); // Generate a 4-digit OTP
}
?>
