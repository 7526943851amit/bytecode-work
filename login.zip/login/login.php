<?php
include 'db.php';
require_once 'twilio-php-main/src/Twilio/autoload.php'; 

session_start();
$sid = "AC7bdddae350379b7d39f5c9016792e295";
$token = "143ac436b4a6d3f3c0d839734aaa36df";
$twilio_number = '+16065190922'; 

if(isset($_POST['submit'])) {
    $phone = $_POST['phone'];
    $_SESSION["login"] = $phone;
    $pass = $_POST['pass'];
   


    $sql = "SELECT * FROM register WHERE phone='$phone' AND Password='$pass'";
    $result = mysqli_query($conn, $sql);

    if($result) {
        if(mysqli_num_rows($result) > 0) {
            $otp = generateOTP();
            $client = new Twilio\Rest\Client($sid, $token);
            $message = $client->messages->create(
                '+91' . $phone,
                array(
                    'from' => $twilio_number,
                    'body' => 'Your OTP for login is: ' . $otp
                )
            );
            
            $_SESSION['otp'] = $otp;
            $_SESSION['phone'] = $phone;
            header("Location: otp_verification.php");
            exit();
        } else {
            echo "Invalid phone or password. Please try again.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
}

function generateOTP() {
    return mt_rand(1000, 9999); 
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
<title>Welcome to Finance Portal</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assests/css/style.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container mt-5 ">
    <form action="" method="post">
		<h2 class="mb-2">Login Form</h2>
        <div class="form-group mt-2">
        	<input type="text" class="form-control" name="phone" placeholder="Phone" required="required">
        </div>
		<div class="form-group">
            <input type="password" class="form-control" name="pass" placeholder="Password" required="required">
        </div>
		<div class="form-group">
            <button type="submit" name="submit" class="btn btn-success btn-lg btn-block">Login</button>
        </div>
        <div class="text-center">Don't have an account? <a href="register.php">Register Here</a></div>
    </form>
</div>
</body>
</html>
