<?php
include 'db.php';

if(isset($_POST['submit'])) {
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $phone = $_POST['phone'];
    $pass = $_POST['pass'];

    $sql = "INSERT INTO register (`First_Name`, `Last_Name`, `phone`, `Password`) VALUES ('$fname', '$lname', '$phone', '$pass')";
    
    if (mysqli_query($conn, $sql)) {
        header("location: register.php?msg=insert");
        die();
    } else {
        echo "Something went wrong. Please try again later.";
    }
} else {
    echo "Form submission error!";
}