<?php
session_start();

if(isset($_POST['submit'])) {
    $enteredOTP = $_POST['otp'];
    if(isset($_SESSION['otp']) && $_SESSION['otp'] == $enteredOTP) {
        header("Location: dashboard.php");
        exit();
    } else {

        echo "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
</head>
<body>
    <h2>OTP Verification</h2>
    <form action="" method="post">
        <label for="otp">Enter OTP:</label><br>
        <input type="text" id="otp" name="otp" required><br><br>
        <input type="submit" name="submit" value="Verify OTP">
    </form>
</body>
</html>
