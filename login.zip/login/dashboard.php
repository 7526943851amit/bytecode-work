<?php
session_start();
if (isset($_SESSION['login'])) {
    echo "<h1 style='text-align:center;margin-top:20px;'>Welcome to dashboard</h1>";
} else {
    header("location: login.php");
    exit(); 
}

include 'db.php';
?>
<div class="container" style='margin-top:100px;text-align:center'>
 
    <?php
$query = "SELECT employees.id as employee_id, employees.employee_name, companies.company_name 
          FROM employees 
          INNER JOIN companies ON employees.company_id = companies.id;";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Employee ID: " . $row["employee_id"] . 
             " | Employee Name: " . $row["employee_name"] . 
             " | Company Name: " . $row["company_name"] . "<br>";
    }
} else {
    echo "0 results";
}

?>
</div>
